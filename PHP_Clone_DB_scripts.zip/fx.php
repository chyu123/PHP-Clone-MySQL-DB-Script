<?php

function showtables($conn_db,$db)
{
    //list table
    $sql = "SHOW TABLES FROM ".$db;
    $result = $conn_master->query($sql);
    $table_list[] = "";
    while ($row1 = $result->fetch_array()) {
        $table_list[] = $row1;
    }
    return $table_list;
}

function copy_data_table($conn_db_master, $conn_db_slave,$db,$table)
{
    erase_table($conn_db_slave, $db, $table);
    $sql_copy = "select * from ".$table;
    $result_copy = $conn_db_master->query($sql_copy);
    while ($row = $result_copy->fetch_array(MYSQLI_ASSOC)) {
        $conn_db_slave->query("insert into ".$table." (" . implode(", ", array_keys($row)) . ") VALUES ('" . implode("', '", array_values($row)) . "')");
    }
}

function erase_table($conn_db,$db,$table)
{
    $sql = "truncate ".$table;
    $conn_db->query($sql);
}



?>